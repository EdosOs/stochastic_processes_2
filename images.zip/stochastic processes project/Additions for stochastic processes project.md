theoretical autocorrelation of X,Y:
new equation:
$$Y^\prime(t) +\beta Y(t) = X(t)$$
by multiplying the new equation by $X(t_2)$ and taking the expectation we get:
$$E[Y(t_1)X(t_2)] +\beta E[Y(t)^\prime X(t_2)] = E[X(t_1)X(t_2)]$$
using the same method we used to find $R_{X,Z}$ we can find $R_{X,Y}$
$$\frac{\partial (R_{X,Y})}{\partial t_2} +\beta R_{X,Y} = R_{X,X} \underset{found \space earlier }{=}  \frac{\sigma^2}{2\alpha} (e^{-\alpha(\lvert t_1-t_2\lvert ) }- e^{-\alpha(t_1+t_2)})\space , \space t_2\ge0,t_1\ge 0$$

We'll solve the ODE with the help of wolfram:
![[Pasted image 20230329115345.png|center]]
$$R_{X,Y} = \int^{t_2}_0e^{-\beta(t_2-\eta)}R_x(t_1,\eta)d\eta = e^{-\beta(t2)}\frac{\sigma^2}{2\alpha}\int^{t2}_0e^{\beta\xi}(-e^{-\alpha(t_1-\xi)}+e^{-\alpha\lvert t_1-\xi\lvert})d\xi+c_1e^{-\beta t_2}$$
with the kind help of the integral calculator i arrived at  = 
![[Pasted image 20230329121253.png|center]]
as the solution of the integral.

we finally arrive at:
$$R_{X,Y} =e^{-\beta(t2)}\frac{\sigma^2}{2\alpha}   \dfrac{\mathrm{e}^{-2{\alpha}t_1}\cdot\left(\left(\left({\beta}-{\alpha}\right)\mathrm{e}^{2{\alpha}t_1}+{\beta}+{\alpha}\right)\mathrm{e}^{{\beta}t_1}-2{\beta}\mathrm{e}^{{\alpha}t_1}\right)}{{\beta}^2-{\alpha}^2} $$
$$R_{X,Y} = \bigg\{^{\dfrac{{\sigma}^2\cdot\left(\mathrm{e}^{2{\alpha}t_1}-1\right)\left(\mathrm{e}^{{\beta}t_2}-\mathrm{e}^{{\alpha}t_2}\right)\mathrm{e}^{-{\beta}t_2-{\alpha}t_2-{\alpha}t_1}}{2{\alpha}\cdot\left({\beta}-{\alpha}\right)} \space\space\space t_2\ge t_1}_{\dfrac{{\sigma}^2\cdot\left(2{\alpha}\mathrm{e}^{-{\beta}t_2-{\alpha}t_1}+\left(\left({\beta}-{\alpha}\right)\mathrm{e}^{2{\alpha}t_2}-{\beta}-{\alpha}\right)\mathrm{e}^{-{\alpha}t_2-{\alpha}t_1}\right)}{2{\alpha}\cdot\left({\beta}^2-{\alpha}^2\right)}t_2<t_1}$$
$$R_{X,Y}(t,t+\tau)$$
Using the same procedure as before:
$$\frac{\partial R_Y(t_1,t_2)}{\partial t_1}+\beta R_Y(t_1,t_2) = R_{X,Y}$$
$$R_Y(t_1,t_2) = \int^{t_1}_{0}e^{-\beta(t_1-\eta)}R_{X,Y}(\eta,t_2)d\eta$$
$$R_{Y}(t,t+\tau) = \frac{\sigma^2}{\beta^2-\alpha^2}(\frac{e^{-\alpha(\vert\tau\vert}-e^{-\alpha(t+\tau)-\beta t }}{2\alpha}+\frac{e^{-\beta\vert\tau\vert}+e^{-\beta(2t+\tau)}}{2\beta}+\frac{e^{-\alpha t-\beta(t+\tau)}+e^{-\beta(2t+\tau)}}{\beta-\alpha})+\frac{\sigma^2}{2\alpha(\beta-\alpha)^2}(e^{-\alpha(t+\tau)-\beta t}-e^{-\alpha(2t+\tau)})$$