-heavy tailed distributions give more emphasis to extreme events (high variance from the mean) therefore they describe extreme events better (such as financial crashes , earthquakes and turbulent flow) 



FFT:
FFT stands for Fast Fourier Transform, which is an algorithm used to efficiently compute the discrete Fourier transform (DFT) of a sequence of time-domain data. The DFT is a mathematical technique used to transform a signal from the time domain to the frequency domain, revealing its frequency content.
DFT:
$$Y(k) = \sum^n_{j = 1}X(j)e^{(-2j\pi fm )}$$
Assumptions for using FFT:

-   The input data should be a finite, discrete set of samples.
-   The data should be evenly spaced in time or space, with a constant sampling rate.
-   The data should be stationary, meaning that the statistical properties of the signal do not change over time.
-   The data should be periodic or have a periodic extension.
-   The data should not have significant spectral leakage, which can occur when the signal contains frequencies that are not integer multiples of the fundamental frequency.

periodogram:
A periodogram is a tool used in signal processing and spectral analysis to estimate the frequency content of a signal. It is a mathematical function that calculates the power spectral density (PSD) of a signal as a function of frequency.

The periodogram is calculated by taking the squared magnitude of the discrete Fourier transform (DFT) of the signal. The resulting values represent the power of the signal at each frequency bin. The periodogram is commonly used in fields such as astronomy, signal processing, and digital signal processing.

egrodity:
"Mean ergodic" and "correlation ergodic" are specific types of ergodicity that describe the properties of a stochastic process or system.

Mean ergodicity refers to the property that the time average of a single realization of a stochastic process converges to the ensemble average as the length of the realization approaches infinity. In other words, for a mean-ergodic process, the long-term behavior of a single realization is representative of the average behavior of the entire ensemble of realizations. This property is important in statistical analysis, as it allows us to estimate the mean of a process using a single realization of the process.

Correlation ergodicity refers to the property that the time average of the correlation function of a single realization of a stochastic process converges to the ensemble average correlation function as the length of the realization approaches infinity. In other words, for a correlation-ergodic process, the long-term correlation structure of a single realization is representative of the correlation structure of the entire ensemble of realizations. This property is important in signal processing and time series analysis, as it allows us to estimate the autocorrelation and cross-correlation functions of a process using a single realization of the process.

Both mean ergodicity and correlation ergodicity are important properties of stochastic processes and systems, as they allow us to use a single realization of a process to estimate the statistical properties of the entire ensemble of realizations. However, not all stochastic processes are ergodic, and the properties of non-ergodic processes can be much more difficult to analyze and predict.


![[Pasted image 20230401094121.png]]