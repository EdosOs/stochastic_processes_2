If X is WSS and $R_x(\tau)$ is continus at $\tau = 0$ X(t) is Mean Square Cont. for all t. 
![[Pasted image 20230226093143.png]]


l.i.m def and ex 
![[Pasted image 20230306092152.png]]



