Edos Osazuwa - 206647414
section 1 :
*1.1.A*
	
	$${X^\prime{(t)}} + \alpha X(t) = Z(t)$$
	By discretization :
	
	$$\frac{dx}{dt}+\alpha x(t) = z(t) \rightarrow {dx}+dt\alpha x(t) = dtz(t)$$
	$$x_{n+1}-x_{n}+x_n\alpha\Delta t = z\Delta t$$
	$$x_{n+1} = x_n(1-\alpha\Delta t)+\Delta w
	
	$$
Using the hint given in the section:
$$E\int^t_0 z(t_1) dt_1\int^t_0 z(t_2) dt_2 \approx E\sum^{\frac{t}{\Delta t}}_{i = 1}zd_i\Delta t\sum^{\frac{t}{\Delta t}}_{i = 1}zd_j\Delta t$$
LHS :
$$E\int^t_0 z(t_1) dt_1\int^t_0 z(t_2) dt_2 = \int^t_0 \int^t_0 E[ z(t_1) dt_1z(t_2) dt_2] = \int^t_0 \int^t_0 R_z(t1,t2)dt_1dt_2 $$$$ \sigma^2\int^t_0 \int^t_0 \delta(t_1-t_2)dt_1dt_2  = \sigma^2 min(t_1,t_2)$$

RHS:
$$E\sum^{\frac{t}{\Delta t}}_{i = 1}zd_i\Delta t\sum^{\frac{t}{\Delta t}}_{i = 1}zd_j\Delta t = \sum^{\frac{t}{\Delta t}}_{i = 1 , j = 1}E[zd_izd_j]\Delta t^2 =  \sum^{\frac{t}{\Delta t}}_{i = j}R_z\Delta t^2\sum^{\frac{t}{\Delta t}}_{i \neq j}R_z\Delta t^2  =\sum^{\frac{t}{\Delta t}}_{i = j}R_z\Delta t^2 $$$$ \sum^{\frac{t}{\Delta t}}_{i = j}\sigma^2\delta(0)\Delta t^2 = \sigma^2t\Delta t = \sigma_d^2min(t_1,t_2) $$
therefore we arrive with the relation

$$\sigma_d^2 = \frac{\sigma^2}{\Delta t} $$
The values I chose are:
$$\alpha = 0.5 , \space \sigma = 1, \space \Delta t = 10^{-2}$$
Now that we have the relation ,	by plugging our result in MATLAB we get the following plots for a several realizations:

![[realizations 3.jpg| center |450x300]]
furthermore if we take the final value of each realization we can arrive with the following histogram:
![[histogram.jpg|center|450x300]]
Using MATLAB fitdist function, and assuming a normal distribution we find that the process is distributed normal with $\mu = -0.0109 \space , \sigma = 10.332$
*1.1.B*
	1. 
		the solution for the ODE is :
		$$x(t) = \int^t_0 e^{-a(t-\eta)}Z(\eta)$$
		we know that the expectation of white noise is zero, we can conclude:
		$$E[X(t)] = E[\int^t_0 e^{-a(t-\eta)}Z(\eta)] = \int^t_0 e^{-a(t-\eta)}E[Z(\eta)] = 0$$
	2.
		We will compute the ensemble average by using the formula $m_x(t) = \frac{1}{N}\sum^N_{i=1}X(t)$
		we get:
		![[ensamble_avg.jpg|center|450x300]]
		RMS (using MATLAB rms function) between the theoretical value(= 0 ) and $X(t)$:0.3154
	3.
		We will compute the  time average by using the formula: $<X(t)>_T = \frac{1}{T}\int^T_1 X(t)dt$ 
		and RMS average by using the RMS MATLAB function and parsing the cumulative sum of each realization.
		we get:![[time_avg.jpg|center|450x300]]
		 RMS between $E(0)$ and $<X(t)>_{t_{final}}$ : 0.0240
		 We conclude that the RMS error is smaller for the time average and this makes sense because the value at final time is much closer to the value of $E[X(0)]$ than the ensemble average

1.1.C
	1. 
		Assuming X(t) is WSS therefore: $E[X(t)] = const \rightarrow E^\prime[X] = 0$ 
		$$R_{Z,X^\prime} = \frac{\partial }{\partial t_2}R_{Z,X} $$ 
		We will show that the equation above holds by comparing the RHS and the LHS.
		RHS:
		
		$$R_{Z,X^\prime} =E[Z(t_1)\underset{\epsilon \rightarrow 0}{l.i.m} \frac{X(t_2+\epsilon) - X(t_2)}{\epsilon}]=\underset{\epsilon \rightarrow 0}{lim}E[ \frac{Z(t_1)X(t_2+\epsilon) - Z(t_1)X(t_2)}{\epsilon}] $$
		$$=\underset{\epsilon \rightarrow 0}{lim}E[ \frac{R_{Z,X}}{\epsilon}] =E[Z(t_1)\frac{\partial X(t_2)}{dt_2}] $$
		as Z is not dependent on t1 and the mean is linear we can take out the derivative by t2 and get:
		$$\frac{\partial}{dt_2} E[Z(t_1) X(t_2)] $$
	2. 
		by multiplying equation in section 1 by $Z(t_1)$  and taking the mean we get:
		$$E[Z(t_1)X(t_2)^\prime + \alpha Z(t_1)X(t_2)] = E[Z(t_1)Z(t_2)]$$
		by mean linearity:
		$$E[Z(t_1)X(t_2)^\prime] +E[ \alpha Z(t_1)X(t_2)] = E[Z(t_1)Z(t_2)]$$
		by autocorrelation definition and the l.i.m properties we showed on section 1:
		$$R_{Z,X^\prime} + \alpha R_{Z,X} = R_Z$$
		which has a similar solution as the Langevin Equation. we get:
		$$R_{Z,X}(t_1,t_2) = \int^{t_2}_{0} e^{-\alpha(t_2-\tau)}R_Z(t_1,\tau)d\tau =\int^{t_2}_{0} e^{-\alpha(t_2-\tau)}\sigma ^2\delta(t_1 - \tau)d\tau $$
		$$\big \{^{0 \space\space\space\space\space\space\space\space\space\space\space\space\space\space\space\space\space\space 0\le t_2<t_1 } _{\sigma ^2e^{-\alpha(t_2-t_1)}\space\space t_2\ge t_1} \underset {\text{u is the step function} \int \delta = u }{=} \sigma ^2e^{-\alpha(t_2-t_1)}u(t_2 - t_1)
		$$
	3.
		by multiplying equation 1 by $X(t_1)$ and taking the mean we get:
		$$E[X(t_1)^\prime X(t_2) + \alpha X(t_1)X(t_2)] = E[Z(t_1)X(t_2)]$$
		by the same a explanation of the previous section:
		$$R_{X^\prime,X} + \alpha R_X = R_{Z,X}$$ $$R_{X}(t_1,t_2) =\int^{t_1}_{0} e^{-\alpha(t_1-\tau)}R_{Z,X}(\tau,t_2)d\tau =\sigma^2 \int^{t_1}_{0} e^{-\alpha(t_2-\tau)}e^{-\alpha(t_1-\tau)}u(t_2 - \tau )d\tau $$$$\sigma^2\int^{min(t_1,t_2)}_{0} e^{-\alpha(t_2-\tau)}e^{-\alpha(t_1-\tau)} d\tau 
		=\sigma^2\int^{min(t_1,t_2)}_{0} e^{-\alpha(t_2-\tau)}e^{-\alpha(t_1-\tau)} d\tau $$$$ \frac{\sigma^2}{2\alpha} (e^{-\alpha(\lvert t_1-t_2\lvert ) }- e^{-\alpha(t_1+t_2)})\space , \space t_2\ge0,t_1\ge 0$$
	5.
		for $t_1 = t \space,\space t_2 = t+\tau \space,\space t\rightarrow \inf$  we get:
		$$R_X(t,t+\tau)\rightarrow \frac{\sigma^2}{2\alpha}e^{-\alpha\lvert \tau\lvert}$$
		We can see from the analytic result above that as t approaches infinity, the dependency on t disappears and we are left with an expression dependent only on time difference $\tau$ therefore the process $X(t)$ when t approaches infinity is a WSS process.
		the calculated and theoretical ensemble average of $R_X$ is: ![[autocorellation 2.jpg|center|450x300]]the value as we reach infinity is revolving around 1 and 95% of the final value is reached at about 3 seconds.
		after experimenting with a few time differences, I chose $\tau_{final}$ to be 15 seconds, we know that for the WSS process as $\tau$ grows, the value of the the similarity(autocorrelation) $X(t)$ with a delayed copy of itself $x(t+\tau)$ as a function of $\tau$ goes to zero. The process is WSS and gaussian therefore markov, it's ergodity property is in question as it doesn't approach $E[X(0)]$ at steady state
		
		
		![[Autocorr as func of tau.jpg|center|450x300]]
		for a mean-ergodic process, the long-term behavior of a single realization is representative of the average behavior of the entire ensemble of realizations
		for a correlation-ergodic process, the long-term correlation structure of a single realization is representative of the correlation structure of the entire ensemble of realizations  
		Therefore we can conclude that $X(t)$ is correlation ergodic because it matches $R_X(\tau)\space for\space t\rightarrow \inf$
		$X(t)$ also satisfies that the ensemble is equal $E[X(t)]$ which is 0. thus it is mean ergodic
 1.1.D
	$S_X = \mathcal{F}(R_X(\tau)) = \int^{\inf}_{-\inf} R_X(\tau)e^{-2j\pi f\tau} = \frac{\sigma^2}{\alpha^2+(2f\pi)^2}$
	A few realizations of the PSD of $X(t)$:
	![[PSD realizations.jpg|center|450x300]]The ensemble average of the PSD along the Theoretical value calculated earlier:![[PSD ensemble avg.jpg|center|450x300]]We can see that the the theoretical model fits the calculated results almost perfectly.


1.1.E
	$$S_{Z,X}(f) =  \mathcal{F}(R_{Z,X}(\tau)) =\int^{\inf}_{-\inf} e^{-\alpha(\tau)-2j\pi f \tau}\sigma ^2u(t_2 - t_1) $$$$ = \frac{\sigma^2}{(\alpha+j2\pi f)}  $$
	We will compute the transfer function by $$S_{Z,X} = H S_Z \rightarrow H =  \frac{\sigma^2}{(\alpha+j2\pi f)} \frac{1}{\sigma^2} = \frac{1}{(\alpha+j2\pi f)}= \frac{1}{(\alpha+s)}$$A few realizations of the cross-PSD of $Z(t),X(t)$:![[cross PSD realizations.jpg|center|450x300]]The ensemble average of the cross PSD along the Theoretical value: ![[cross PSD ensemble avg 1.jpg|center|450x300]]
	Coherence is defined by:$$\frac{\lvert S_{Z,X}\lvert^2}{S_XS_Z} =\frac{ \frac{\sigma^4{(\alpha^2+(2f\pi)^2)}}{(\alpha^2+4\pi^2 f^2)}}{\sigma^4} = 1$$
	we arrived at coherence equals 1 therefore X,Z are ideally connected through a linear system.
	The calculated coherence along with the calculated theoretical coherence:![[Coherence.jpg|center|450x300]]in conclusion, I think we can safely assume that the theory suits the analytical calculations for the most part for the lavgevin equation with white gaussian noise. 
	By these conclusions (coherence equals 1, perfect correlation) $X(t)$ is related to Z through a linear system where Z is white gaussian noise and serves as the input $Z(t)\rightarrow[Linear SYS] \rightarrow X(t)$ 



1.2.A
	1.1.A
			In this section I skipped most of the analytical calculations as they proved to be fairly complicated, but still we can obtain all the numerical expressions and calculations.
			I chose the first option:$${Y^\prime{(t)}} + \beta Y(t) = X(t)$$
		By the same discretization as earlier we arrive at:
		
		$$\frac{dY}{dt}+\beta Y(t) = X(t) \rightarrow {dY}+dt\beta Y(t) = dtX(t)$$
		$$Y_{n+1}-Y_{n}+Y_n\beta\Delta t = X\Delta t$$
		A few relizations of the process Y:![[realizations 4.jpg|center|450x300]]
		histogram of $Y(t_{final})$
		![[histogram 2.jpg|center|450x300]]
		Where again by using fitdist we arrive at a normal distribution with $\mu = 0.1557 , \sigma = 14.5357$
	1.1.B
		1. 
		the solution for the ODE is :$$Y(t) = \int^t_0 e^{-a(t-\eta)}X(\eta)d\eta$$
		As we showed earlier the expectation of $X(t)$ is zero.
		we can conclude:
		$$E[Y(t)] = E[\int^t_0 e^{-a(t-\eta)}X(\eta)]  = 0  \int^t_0 e^{-a(t-\eta)}E[X(\eta)] \small\underset{E(X(t)) = 0}= 0$$
		2.
		The ensemble average of a few realizations:![[ensemble_avg.jpg|center|450x300]]
		The RMS of the ensemble average is: 0.4464
		3.
		The time average of a few realizations:![[time_avg 1.jpg|center|450x300]]
		The time average RMS is :0.0510
	1.1.C
		Assuming X(t) is WSS therefore: $E[X(t)] = const \rightarrow E^\prime[X] = 0$ 
		$$R_{X,Y^\prime} = \frac{\partial }{\partial t_2}R_{X,Y} $$ 
		The equation above holds by the same proof we showed earlier in section 1.1.C
		therefore, we will show what the autocorrelation function looks like :![[autocorellation 4.jpg|center|450x300]]
		As we can see, the Autocorrelation $R_Y(t,t)$ is reaching 95% of its final value (which is approximately 2) after about 5 seconds.
		By the same logic as beforehand, i experimented with different values of $\tau_{final}$ and saw that $\tau_f = 15 [sec]$ is sufficient for showing the full range of values of the autocorrelation (finally it should approach 0 of course because the process is WSS) The process is markov as it's WSS and gaussian(because X is gaussian), I'm not sure if it's mean ergodic as it's not reaching $E[X(0)]$ (=0) in steady state.
		The autocorrelation as a function of $\tau$ looks like:![[Autocorr as func of tau 1.jpg|center|450x300]]
		Where I decided to add a mean of the realizations to show a rough approximation of how the theoretical graph would have looked and give a certain reference point, as we can see our assumption of WSS is realized here as the similarity approaches zero as $\tau$ grows.
	1.1.D 
		A few realizations of the PSD of $Y(t)$:![[psdY.jpg|center|450x300]]
		The ensemble average of the PSD:![[psdYensamble.jpg|center|450x300]]
	1.1.E
		The PSD of X,Y is the following:![[cross PSD YX.jpg|center|450x300]]
		The cross PSD of X,Y is:![[cross PSD YX ensemble.jpg|center|450x300]]
		And the coherence:
		![[coherence XY.jpg|center|450x300]]
		We see an interesting phenomenon, as the frequency grows, the coherence between X,Y is decreasing.
		They way I see it, X,Y are highly correlated at low frequencies when we have minimal noise but at high frequencies where we counter substantial noise we see the correlation drop. 



1.2.B
	1.1.A
		for this section i decided to use the log-normal distribution therefore $Z = e^{\mu+\sigma Z}$ , a heavy tailed distribution that resembles the normal distribution which means its pdf is skewed a little bit (has some outliers) to either of the right or left (or both).
		The mean of the log-normal distribution is $\mu_{log-normal} = e^{\mu+\frac{\sigma^2}{2}}$ and its variance is $\sigma^2_{log-normal} = (e^{\sigma^2}-1)e^{2\mu+\sigma^2}$  ,for this section i used $\sigma^2_{log-normal} = 1 \space , \mu^2_{log-normal} = 1 \rightarrow \sigma = 2.148 \space , \mu = -2.307$  
		A few realizations of the log normal process:![[realizations 5.jpg|center|450x300]]
		When plotting the histogram of the process i used both the values and the ln of the values because in the log-normal distribution $\ln(X)~N(\mu,\sigma^2)$
		histogram of values:![[hist_non_logged.jpg|center|450x300]]histogram of $\ln(values)$:
		 ![[hist_logged.jpg|center|450x300]]
		 $\mu = 0.633 , \sigma = 0.316$
	 1.1.B
		 As for the averages, the ensemble average![[ensemble_avg222.jpg|center|450x300]]
		 Ensemble average RMS = 1.989
		 And the time average:![[time avg.jpg|center|450x300]]
		With RMS error of 1.987
		We end up with very similar errors, maybe because of the logarithmic nature of the distribution which might make distant values seem close.
	1.1.C
		Since we know the distribution of Z, we can calculate the autocorrelation function $R_x(t,t)$.
		we know that:$$X(t) = \int^t_0 e^{-a(t-\eta)}Z(\eta)$$
		Using autocorrelation definition:
		$$R_{X}(t_1,t_2) = E[X(t_1)X(t_2)]= \int^{t_1}_{0} \int^{t_2}_{0} e^{-\alpha(t_1-\eta)}e^{-\alpha(t_2-\theta)}E[Z(\eta)Z(\theta)]d\eta d\theta $$
		For white noise process$$R_z(t_1,t_2) =E[Z(t_1)Z(t_2)]=\sigma^2\delta_{n_1,n_2}+\mu^2 $$$$R_{X}(t_1,t_2) = e^{-\alpha(t_1+t_2)}\int^{t_1}_{0} \int^{t_2}_{0} e^{\alpha(\eta+\theta)}(\sigma_{ln}(\eta-\theta)+\mu_{ln}^2)d\eta d\theta$$$$R_{X}(t_1,t_2) =e^{-\alpha(t_1+t_2)}\int^{t_1}_{0} \int^{t_2}_{0} e^{\alpha(\eta+\theta)}(\sigma_{ln}(\eta-\theta)+\mu_{ln}^2)d\eta d\theta $$
		$$R_{X}(t_1,t_2) =e^{-\alpha(t_1+t_2)}(\int^{min(t_1,t_2)}_{0}\sigma_{ln}e^{2\alpha\theta}d\theta +\mu_{ln}^2 \int^{t_1}_{0}e^{\alpha\eta}d\eta \int^{t_2}_{0} e^{\alpha\theta}d\theta $$
		at last we get$$R_X(t_1,t_2) = e^{-\alpha(t_1+t2)} (\frac{\sigma_{ln}}{2\alpha}[e^{\alpha min(t_1,t_2)}-1]) + \frac{\mu_{ln}^2}{\alpha^2}(e^{\alpha t_1}-1)(e^{\alpha t_2}-1)$$
		$$R_X(t_1,t_2) = e^{-\alpha(t_1+t2)} (\frac{\sigma_{ln}}{2\alpha}[e^{\alpha min(t_1,t_2)}-1]) + \frac{\mu_{ln}^2}{\alpha^2}(e^{\alpha t_1}-1)(e^{\alpha t_2}-2)$$
		$$R_X(t,t) =\frac{\mu_{ln}^2}{\alpha^2}(1-2e^{-\alpha t}+e^{-2\alpha t})+ \frac{\sigma_{ln}}{2\alpha}(1-e^{-2\alpha t})$$
		$$R_X(t,t+\tau) = \bigg\{^{ e^{-\alpha(2t+\tau)} (\frac{\sigma_{ln}}{2\alpha}[e^{\alpha (t+\tau)}-1]) + \frac{\mu_{ln}^2}{\alpha^2}(e^{\alpha t}-1)(e^{\alpha (t+\tau)}-1)\space\space\space \tau>0} _
		{e^{-\alpha(2t+\tau)} (\frac{\sigma_{ln}}{2\alpha}[e^{\alpha t)}-1]) + \frac{\mu_{ln}^2}{\alpha^2}(e^{\alpha t}-1)(e^{\alpha (-\alpha(2t+\tau)}-1)\space\space\space \tau<0}$$
		as $t \rightarrow \inf$ we get:$$R_X(t,t+\tau) = \frac{\mu_{ln}^2}{\alpha^2}+\frac{\sigma_{ln}}{2\alpha}e^{-\alpha\lvert\tau\lvert}$$
		at last we can look at what we have calculated.![[autocorrensembeleWtheo.jpg|center|450x300]]
		![[autocorrAsFuncOf Tau 2.jpg|center|450x300]]As we can see, the theory suits our calculations pretty neatly.
		I think we can also assume its not ergodic as it definitely not approaching$E[X(0)]$ in steady state.
		furthermore i don't think it can be cataloged as markov since it is not gaussian.
	1.1.D
		similarly to the first section we'll find the furier transform of t the process to find it's PSD$$S_X(f) =\mathcal{F}(R_X(t,t+\tau)) = \frac{\sigma_{ln}}{\alpha^2+4\pi^2f^2}+\frac{\mu_{ln}^2}{\alpha^2} $$![[PSDREAL.jpg|center|450x300]]
		![[PSDENSEMBLE 1.jpg|center|450x300]]
		We see that for lower frequencies the theory describes the
	1.1.E
		Again, like earlier we'll calculate the cross PSD
		$$S_{Z,X}(f) =\mathcal{F}(R_{Z,X}(t,t+\tau)) =\frac{\mu_{ln}^2}{\alpha}+\frac{\sigma_{ln}}{\alpha+2\pi fj}$$![[CPSDREAL.jpg|center|450x300]]
		![[CPSDENSAMBLE.jpg|center|450x300]]
		coherence calculation, as we did previously, by definition$$S_{Z} = \mathcal{F}(R_{Z}(t,t+\tau) =\sigma_{ln}+\mu_{ln}^2 $$
		$$\frac{\lvert S_{Z,X}\lvert^2}{S_XS_Z} = 1$$
		$$S_{Z,X} = H S_Z \rightarrow H =\frac{1}{\alpha+2\pi fj}  \underset{laplace}= \frac{1}{\alpha+s}  $$
2
	1 A few measurements:![[measures.jpg|center|450x300]]
	These signals are random in my opinion because of the way they are generated, the signals are created through an experiment in a wind tunnel and I think (I'm not very familiar with those) that the behavior of the motion and posture DOFs can be modeled as a random process because the flow (which determines the motion and posture DOFs) can be modeled as a random process.
	This resembles a linear system for which the wind is the input signal , and the response is the motion and posture DOFs.
	In such systems the behavior of the input is similar to the output   
	normalized eigenvalues:![[eigvals.jpg|center|450x300]]
	15 most significant signals (i decided to plot the first, 10th and 15th otherwise the graph is really packed and not understandable) ![[Mostsignificant15.jpg|center|450x300]]
	some of the most significant signals and yaw rate![[yaw rate ctrl.jpg|center|700x500]]
	we can notice that the yaw rate amplitude is a lot bigger (at least order of magnitude) from even the most significant control signal.
	I think it's safe to assume that we can ignore smaller eigenvalues because we see that the magnitude of the control signal is correlated to the magnitude of its eigenvalue 
	the correlation coefficient as a function of time for the various velocities:![[corr_coeff_vels.jpg|700x400]]
	the cross correlation function is dependent on time difference alone only if both processes $(z,u)$ are stationary.
	from the graphs above we can see that for most movements the correlation coefficient is high at small time differences and big time differences. for small time differences it makes sense because we are close to the initial condition and thus should be fairly similar as noise didn't yet develop.
	I'm not sure if there's good evidence to support the claim that each pattern is generated by a specific motion as it seems that there is a dependency between some of the movements (they have similar development over the time differences.)
	my suggestion for checking whether each movement pattern is responsible to a certain motion is to try and isolate a movement pattern as much as possible (probably requires very high skill) and maybe add more sensors to body parts that are more crucial for a certain movement pattern.